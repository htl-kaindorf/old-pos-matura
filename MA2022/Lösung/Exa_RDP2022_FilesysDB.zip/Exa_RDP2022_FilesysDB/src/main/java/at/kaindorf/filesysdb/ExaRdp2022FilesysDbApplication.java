package at.kaindorf.filesysdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExaRdp2022FilesysDbApplication {

  public static void main(String[] args) {
    SpringApplication.run(ExaRdp2022FilesysDbApplication.class, args);
  }

}
