package at.kaindorf.filesysdb.pojos;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 29.03.2023
 * Time: 15:25
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type")
@Table(name = "file_object")
@EqualsAndHashCode(exclude = {"id", "lastModified", "parent"})
public class FileObject {

  @Id
  @GeneratedValue(generator = "file_object_seq")
  @SequenceGenerator(name = "file_object_seq", initialValue = 1000, allocationSize = 1)
  private Long id;
  private String name;
  @Column(name = "last_modified")
  private LocalDateTime lastModified;

  @ToString.Exclude
  @ManyToOne
  @JoinColumn(name = "parent")
  private Directory parent;
}
