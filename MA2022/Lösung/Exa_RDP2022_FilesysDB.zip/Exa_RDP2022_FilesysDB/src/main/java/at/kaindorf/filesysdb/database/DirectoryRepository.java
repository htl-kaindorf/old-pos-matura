package at.kaindorf.filesysdb.database;

import at.kaindorf.filesysdb.pojos.Directory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 20.04.2023
 * Time: 08:08
 */
public interface DirectoryRepository extends JpaRepository<Directory, Long> {
 // public Directory getByXY(String dirname);
  @Query("SELECT d FROM Directory d WHERE d.name = ?1 AND d.parent = ?2")
  public Directory getDirByNameInCurrentDir(String dirname, Directory directory);
  public Directory getDirectoryByName(String dirname);
}
