package at.kaindorf.filesysdb.pojos;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 29.03.2023
 * Time: 15:25
 */
@Entity
@DiscriminatorValue("LINK")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Link extends FileObject{
  private String source;
}
