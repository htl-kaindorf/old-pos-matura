package at.kaindorf.filesysdb.database;

import at.kaindorf.filesysdb.pojos.FileItem;
import at.kaindorf.filesysdb.pojos.Link;
import org.springframework.data.jpa.repository.JpaRepository;

import java.io.InputStream;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 20.04.2023
 * Time: 08:10
 */
public interface LinkRespository extends JpaRepository<Link, Long> {
}
