package at.kaindorf.filesysdb.pojos;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 29.03.2023
 * Time: 15:25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DiscriminatorValue("FILE")
public class FileItem extends FileObject{
  private Long size;

  public FileItem(Long id, String name, LocalDateTime lastModified, Directory parent, Long size) {
    super(id, name, lastModified, parent);
    this.size = size;
  }
}
