package at.kaindorf.filesysdb.database;

import at.kaindorf.filesysdb.pojos.FileItem;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 20.04.2023
 * Time: 08:09
 */
public interface FileItemRepository extends JpaRepository<FileItem, Long> {
}
