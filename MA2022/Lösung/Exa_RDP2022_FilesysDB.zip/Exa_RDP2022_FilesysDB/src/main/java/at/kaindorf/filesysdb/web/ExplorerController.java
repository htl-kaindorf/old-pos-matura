package at.kaindorf.filesysdb.web;

import at.kaindorf.filesysdb.database.DirectoryRepository;
import at.kaindorf.filesysdb.database.FileItemRepository;
import at.kaindorf.filesysdb.pojos.Directory;
import at.kaindorf.filesysdb.pojos.FileItem;
import at.kaindorf.filesysdb.pojos.FileObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.time.LocalDateTime;
import java.util.Random;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 20.04.2023
 * Time: 08:13
 */
@Controller
@RequestMapping("/explorer")
@Slf4j
@RequiredArgsConstructor
@SessionAttributes({"currentDir"})
public class ExplorerController {

  private final DirectoryRepository dirRepo;
  private final FileItemRepository fileRepo;

  @GetMapping
  public String getDirContent(Model model, @RequestParam(value = "dirName", defaultValue = "C:") String dirName) {
    Directory currentDir = null;
    if (dirName.equals("C:")) {
      currentDir = dirRepo.getDirectoryByName(dirName);
    } else {
      currentDir = (Directory) model.getAttribute("currentDir");
      currentDir = dirRepo.getDirByNameInCurrentDir(dirName, currentDir);
    }
    updateModel(model, currentDir);
    return "ExplorerView";
  }

  @PostMapping("/up")
  public String getUpDirContent(Model model) {
    Directory currentDir = (Directory) model.getAttribute("currentDir");
    if (currentDir.getParent() != null) {
      currentDir = currentDir.getParent();
    }
    updateModel(model, currentDir);
    return "ExplorerView";
  }

  @PostMapping("/create")
  public String createContent(Model model, FileObject newFileObject, @RequestParam("type") String type) {
    Directory currentDir = (Directory) model.getAttribute("currentDir");
    Random rand = new Random();
    switch (type) {
      case "directory":
        Directory newDir = new Directory(null, newFileObject.getName(),
            LocalDateTime.now(), currentDir);
        currentDir.addFileObject(newDir);
        dirRepo.save(newDir);
        break;
      case "file":
        FileItem newFile = new FileItem(null, newFileObject.getName(),
            LocalDateTime.now(), currentDir, rand.nextLong(100, 10_000));
        currentDir.addFileObject(newFile);
        fileRepo.save(newFile);
        break;
    }
    updateModel(model, currentDir);
    return "ExplorerView";
  }

  private void updateModel(Model model, Directory currentDir) {
    model.addAttribute("currentDir", currentDir);
    model.addAttribute("content", currentDir.getContent());
    model.addAttribute("dirPath", getDirPath(currentDir));
    model.addAttribute("newFileObject", new FileObject());
  }

  private String getDirPath(Directory currentDir) {
    String dirPath = currentDir.getName();
    currentDir = currentDir.getParent();
    while (currentDir != null) {
      dirPath = currentDir.getName() + File.separator + dirPath;
      currentDir = currentDir.getParent();
    }
    return dirPath;
  }
}
