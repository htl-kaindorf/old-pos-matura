package at.kaindorf.filesysdb.pojos;

import jakarta.persistence.*;
import lombok.*;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Project: Exa_RDP2022_FilesysDB
 * Created by: SF
 * Date: 29.03.2023
 * Time: 15:25
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DiscriminatorValue("DIR")
//@NamedQueries({
//    @NamedQuery(name = "Directory.getByXY", query="SELECT d FROM Directory d WHERE ...")
//})
public class Directory extends FileObject{

  public Directory(Long id, String name, LocalDateTime lastModified, Directory parent) {
    super(id, name, lastModified, parent);
  }

  @ToString.Exclude
  @OneToMany(mappedBy = "parent", cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.EAGER)
  private List<FileObject> content;

  public void addFileObject(FileObject fileObject) {
    if (!content.contains(fileObject)) {
      content.add(fileObject);
      fileObject.setParent(this);
    }
  }

}
