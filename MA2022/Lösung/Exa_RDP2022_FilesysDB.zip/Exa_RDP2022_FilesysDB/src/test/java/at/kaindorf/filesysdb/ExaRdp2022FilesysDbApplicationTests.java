package at.kaindorf.filesysdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExaRdp2022FilesysDbApplicationTests {

  @Test
  void contextLoads() {
  }

}
