package ui;

import consumer.PasswordCrackerConsumer;
import java.io.File;
import observer.ResultLogger;
import producer.UserEntryProducer;
import queue.EntryQueue;
import strategy.CrackFirstToLast;
import strategy.PasswordCrackerStrategy;

public class Main {

  public static void main(String[] args) {
    try{

      final String pwdFile = "rockyou_small.txt";

      EntryQueue queue = new EntryQueue(10);

      PasswordCrackerStrategy firstToLast = new CrackFirstToLast(pwdFile);

      UserEntryProducer p1 = new UserEntryProducer(queue, pwdFile);
      UserEntryProducer p2 = new UserEntryProducer(queue, pwdFile);

      ResultLogger logger = new ResultLogger(new File("out.log"));

      PasswordCrackerConsumer c1 = new PasswordCrackerConsumer(queue, firstToLast);
      PasswordCrackerConsumer c2 = new PasswordCrackerConsumer(queue, firstToLast);
      PasswordCrackerConsumer c3 = new PasswordCrackerConsumer(queue, firstToLast);
      PasswordCrackerConsumer c4 = new PasswordCrackerConsumer(queue, firstToLast);

      c1.register(logger);
      c2.register(logger);
      c3.register(logger);
      c4.register(logger);

      new Thread(p1, "Producer 1").start();
      new Thread(p2, "Producer 2").start();

      new Thread(c1, "Consumer 1").start();
      new Thread(c2, "Consumer 2").start();
      new Thread(c3, "Consumer 3").start();
      new Thread(c4, "Consumer 4").start();

    }catch(Exception e){
      System.err.println(e.getMessage());
    }
  }

}
