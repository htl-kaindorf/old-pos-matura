package observer;

import consumer.CrackResult;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.Instant;
import java.time.LocalDateTime;

public class ResultLogger implements ResultObserver{

  private File f;

  public ResultLogger(File f) {
    this.f = f;
  }

  @Override
  public synchronized void result(CrackResult result) {

    try{

      PrintWriter pw = new PrintWriter(new FileWriter(f, true));

      pw.format("%s;%s;%s;%d;%s%n",
          Instant.now(),
          result.getUserEntry().pwdHashBase64(),
          result.getCrackedPwd(),
          result.getDuration(),
          result.getCrackStrategy()
          );

      pw.close();

    }catch(Exception e){
      System.err.println(e.getMessage());
    }
  }
}
