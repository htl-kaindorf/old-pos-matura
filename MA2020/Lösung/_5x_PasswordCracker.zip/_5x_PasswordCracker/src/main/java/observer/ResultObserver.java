package observer;

import consumer.CrackResult;

public interface ResultObserver {

  void result(CrackResult result);

}
