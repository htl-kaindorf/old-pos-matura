package observer;

import consumer.CrackResult;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public abstract class ResultSubject {

  private Set<ResultObserver> observers = new HashSet<>();


  public void register(ResultObserver observer){
    observers.add(observer);
  }

  public void unregister(ResultObserver observer){
    observers.remove(observer);
  }

  public void inform(CrackResult crackResult){
    observers.forEach(o -> o.result(crackResult));
  }

}
