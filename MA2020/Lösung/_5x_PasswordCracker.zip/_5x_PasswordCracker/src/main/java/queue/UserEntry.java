package queue;

import java.util.Arrays;
import java.util.Base64;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UserEntry {
  private String username;
  private byte[] passwordHash;

  @Override
  public String toString() {
    return "UserEntry{" +
        "username='" + username + '\'' +
        ", passwordHash=" + pwdHashBase64() +
        '}';
  }

  public String pwdHashBase64() {
    return Base64.getEncoder().encodeToString(passwordHash);
  }
}
