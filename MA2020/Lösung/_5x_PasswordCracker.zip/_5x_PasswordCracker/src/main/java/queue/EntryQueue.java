package queue;

import java.util.LinkedList;

public class EntryQueue {

  private final LinkedList<UserEntry> entries = new LinkedList<UserEntry>();
  private final int maxsize;

  public EntryQueue(int maxsize) {
    this.maxsize = maxsize;
  }

  public boolean isFull(){
    return entries.size() >= maxsize;
  }

  public boolean isEmpty(){
    return entries.isEmpty();
  }

  public void pushEntry(UserEntry entry) throws InterruptedException {

    synchronized (entries){
      while(isFull()){
        entries.wait();
      }
      entries.add(entry);
      entries.notifyAll();
    }
  }

  public UserEntry popEntry() throws InterruptedException {
    synchronized (entries){
      while(isEmpty()){
        entries.wait();
      }
      UserEntry e = entries.removeFirst();
      entries.notifyAll();
      return e;
    }
  }

  @Override
  public String toString() {
    return "EntryQueue{" +
        "entries=" + entries +
        ", maxsize=" + maxsize +
        '}';
  }
}
