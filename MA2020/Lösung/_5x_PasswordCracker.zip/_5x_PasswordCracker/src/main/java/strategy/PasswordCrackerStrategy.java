package strategy;

public interface PasswordCrackerStrategy {
  String crackPassword(byte[] hash);
  String getName();
}
