package strategy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import producer.HashGenerator;
import producer.UserEntryProducer;

public class CrackFirstToLast implements PasswordCrackerStrategy{

  private final String filename;

  private List<String> passwords;

  public CrackFirstToLast(String filename) throws IOException {
    this.filename = filename;

    passwords =
//        Files.readAllLines(
//        Path.of(UserEntryProducer.class.getClassLoader().getResource(passwordFile).getPath())


        Files.readAllLines(
            Paths.get(System.getProperty("user.dir"),"src","main","resources",filename)
        );
  }

  @Override
  public String crackPassword(byte[] hash) {
    return passwords.stream().filter(pw ->
    {
      try {
        return Arrays.equals(HashGenerator.pwdToHash(pw), hash);
      } catch (NoSuchAlgorithmException e) {
        System.err.println(e.getMessage());
      }
      return false;
    }).findFirst().orElse(null);
  }

  @Override
  public String getName() {
    return "CrackFirstToLast";
  }
}
