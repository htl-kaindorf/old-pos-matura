package consumer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import queue.UserEntry;

@Getter
@Setter
@AllArgsConstructor
public class CrackResult {
  private UserEntry userEntry;
  private String crackedPwd;
  private long duration;
  private String crackStrategy;

  @Override
  public String toString() {
    return "CrackResult{" +
        "userEntry=" + userEntry +
        ", crackedPwd='" + crackedPwd + '\'' +
        ", duration=" + duration +
        ", crackStrategy='" + crackStrategy + '\'' +
        '}';
  }
}
