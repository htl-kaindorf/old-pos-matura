package consumer;

import java.security.NoSuchAlgorithmException;
import observer.ResultSubject;
import producer.HashGenerator;
import queue.EntryQueue;
import queue.UserEntry;
import strategy.PasswordCrackerStrategy;

public class PasswordCrackerConsumer extends ResultSubject implements Runnable{

  private final EntryQueue queue;
  private final PasswordCrackerStrategy strategy;

  public PasswordCrackerConsumer(EntryQueue queue, PasswordCrackerStrategy strategy) {
    this.queue = queue;
    this.strategy = strategy;
  }
//
//  public boolean test(String hash, String pwd) throws NoSuchAlgorithmException {
//    return hash.equals(HashGenerator.pwdToHash(pwd));
//  }

  @Override
  public void run() {
    while(!Thread.interrupted()){
      try {
        UserEntry u = queue.popEntry();
        long start = System.currentTimeMillis();

        String pwd = strategy.crackPassword(u.getPasswordHash());

        long duration = System.currentTimeMillis() - start;

        CrackResult result = new CrackResult(u, pwd, duration, strategy.getName());
        System.out.println(result);

        inform(result);

      } catch (InterruptedException e) {
        System.err.println(e.getMessage());
      }

    }
  }
}
