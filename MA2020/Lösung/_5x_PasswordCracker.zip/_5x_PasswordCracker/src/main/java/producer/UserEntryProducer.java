package producer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;
import queue.EntryQueue;
import queue.UserEntry;

public class UserEntryProducer implements Runnable{

  private final EntryQueue queue;
  private final String passwordFile;
  private final List<String> passwords;

  public UserEntryProducer(EntryQueue queue, String passwordFile) throws IOException {
    this.queue = queue;
    this.passwordFile = passwordFile;

    passwords =
//        Files.readAllLines(
//        Path.of(UserEntryProducer.class.getClassLoader().getResource(passwordFile).getPath())


    Files.readAllLines(
        Paths.get(System.getProperty("user.dir"),"src","main","resources",passwordFile)
    );
  }

  @Override
  public void run() {
    while(!Thread.interrupted()){

      try {
        Thread.sleep(1000);
        String username = "user"+System.currentTimeMillis();
        byte[] pwdHash = HashGenerator.pwdToHash(
          passwords.get(new Random().nextInt(passwords.size()))
        );
        UserEntry entry = new UserEntry(username,pwdHash);
        queue.pushEntry(entry);
      } catch (Exception e) {
        System.err.println(e.getMessage());
      }

    }
  }
}
