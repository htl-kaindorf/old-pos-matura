package at.kaindorf.customerdb.pojos;

/**
 * Project: RP_POS1_FT_19_20
 * Created by: SF
 * Date: 24.04.2023
 * Time: 10:14
 */
public enum Gender {
  MALE,
  FEMALE;
}

