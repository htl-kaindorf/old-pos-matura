package at.kaindorf.customerdb.pojos;

import java.util.List;

/**
 * Project: RP_POS1_FT_19_20
 * Created by: SF
 * Date: 24.04.2023
 * Time: 10:10
 */
public class Country {
  private Long countryId;
  private String countryName;
  private String countryCode;

}
