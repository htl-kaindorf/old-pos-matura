package at.kaindorf.customerdb.pojos;


import java.time.LocalDate;

/**
 * Project: RP_POS1_FT_19_20
 * Created by: SF
 * Date: 24.04.2023
 * Time: 10:13
 */
public class Customer {
  private Long customerId;
  private String firstname;
  private String lastname;
  private Gender gender;
  private LocalDate dateOfBirth;

}
